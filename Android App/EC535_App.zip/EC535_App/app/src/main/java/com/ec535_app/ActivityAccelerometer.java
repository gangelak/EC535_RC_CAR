package com.ec535_app;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.gson.Gson;

import java.lang.ref.WeakReference;
import java.util.Locale;

import static java.lang.Math.round;

public class ActivityAccelerometer extends Activity implements SensorEventListener {


    private SensorManager mSensorManager;
    private Sensor mAccel;
    private BTconnect bl = null;

    private int xAxis = 0;
    private int yAxis = 0;
    private int motorLeft = 0;
    private int motorRight = 0;
    private String address;
    private BluetoothDevice device;
    private boolean show_Debug;
    private boolean BT_is_connect;
    private int xMax;
    private int yMax;
    private int yThreshold;
    private int pwmMax;
    private int xR;
    private String commandLeft;
    private String commandRight;
    private Intent intent = new Intent();
    ToggleButton Pause ;
    ToggleButton Auto ;
    private boolean pressed;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accelerometer);

        Gson gson = new Gson();
        intent = getIntent();



        address = intent.getStringExtra("address");
        device = gson.fromJson(intent.getStringExtra("device"), BluetoothDevice.class);
        xMax = Integer.parseInt((String) getResources().getText(R.string.default_xMax));
        xR = Integer.parseInt((String) getResources().getText(R.string.default_xR));
        yMax = Integer.parseInt((String) getResources().getText(R.string.default_yMax));
        yThreshold = Integer.parseInt((String) getResources().getText(R.string.default_yThreshold));
        pwmMax = Integer.parseInt((String) getResources().getText(R.string.default_pwmMax));
        commandLeft = (String) getResources().getText(R.string.default_commandLeft);
        commandRight = (String) getResources().getText(R.string.default_commandRight);
        pressed = false;

        loadPref();

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mAccel = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Pause = (ToggleButton) findViewById(R.id.pause);
        Auto = (ToggleButton) findViewById(R.id.auto);

        bl = new BTconnect(device, mHandler, address);
        bl.checkBTState();


        mHandler.postDelayed(sRunnable, 600000);

    }

    private static class MyHandler extends Handler {
        private final WeakReference<ActivityAccelerometer> mActivity;


        public MyHandler(ActivityAccelerometer activity) {
            mActivity = new WeakReference<ActivityAccelerometer>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            ActivityAccelerometer activity = mActivity.get();
            if (activity != null) {
                switch (msg.what) {
                    case BTconnect.BL_NOT_AVAILABLE:
                        Toast.makeText(activity.getBaseContext(), "Bluetooth is not available", Toast.LENGTH_SHORT).show();
                        activity.finish();
                        break;
                    case BTconnect.BL_INCORRECT_ADDRESS:
                        Toast.makeText(activity.getBaseContext(), "Incorrect Bluetooth address", Toast.LENGTH_SHORT).show();
                        break;
                    case BTconnect.BL_REQUEST_ENABLE:
                        BluetoothAdapter.getDefaultAdapter();
                        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        activity.startActivityForResult(enableBtIntent, 1);
                        break;
                    case BTconnect.BL_SOCKET_FAILED:
                        Toast.makeText(activity.getBaseContext(), "Socket failed", Toast.LENGTH_SHORT).show();
                        //activity.finish();
                        break;
                    case BTconnect.RFCOMM_FAILED:
                        Toast.makeText(activity.getBaseContext(), "Failed to Create RFCOMM channel", Toast.LENGTH_SHORT).show();
                        break;

                }
            }
        }
    }

    private final MyHandler mHandler = new MyHandler(this);

    private final static Runnable sRunnable = new Runnable() {
        public void run() {
        }
    };

    public void onToggleClicked(View view) {
        // Is the toggle on?
        boolean on = ((ToggleButton) view).isChecked();

        if (on) {
            pressed = true;
        } else {
            pressed = false;
        }
    }

    public void onAutoClicked(View view) {
        // Is the toggle on?
        boolean on = ((ToggleButton) view).isChecked();
        String cmdSend = "";

        if (on) {
            cmdSend = "N";
            if (BT_is_connect) bl.sendData(cmdSend+"\r");
        } else {
            cmdSend = "B";
            if (BT_is_connect) bl.sendData(cmdSend+"\r");
        }
    }


    public void onSensorChanged(SensorEvent e) {
        String directionL = "";
        String directionR = "";
        String cmdSend = "";

        if (pressed == true){
            cmdSend = "S";
            if (BT_is_connect) bl.sendData(cmdSend+"\r");
            return;
        }



        xAxis = (int)round(e.values[0]);
        yAxis = (int)round(e.values[1]);

        if (yAxis == 0 && xAxis == 0){
            cmdSend = "S";
        }
        else if (xAxis < -1 && yAxis ==0){
            cmdSend = "F";
        }
        else if (xAxis > 1 && yAxis ==0){
            cmdSend = "B";
        }
        else if(xAxis == 0 && yAxis < -1){
            cmdSend = "L";
        }
        else if (xAxis == 0 && yAxis > 1){
            cmdSend = "R";
        }
        else if (xAxis < -1 && yAxis < -1){
            cmdSend = "Q";
        }
        else if(xAxis < -1 && yAxis > 1){
            cmdSend = "E";
        }
        else if (xAxis > 1 && yAxis < -1){
            cmdSend = "A";
        }
        else if (xAxis > 1 && yAxis > 1){
            cmdSend = "D";
        }
        else{
            cmdSend = "S";
        }

        if (BT_is_connect) bl.sendData(cmdSend+"\r");

        TextView textX = (TextView) findViewById(R.id.textViewX);
        TextView textY = (TextView) findViewById(R.id.textViewY);
        TextView mLeft = (TextView) findViewById(R.id.mLeft);
        TextView mRight = (TextView) findViewById(R.id.mRight);
        TextView textCmdSend = (TextView) findViewById(R.id.textViewCmdSend);

        if (show_Debug) {
            textX.setText(String.valueOf("X:" + String.format("%.1f", e.values[0]) + "; xPWM:" + xAxis));
            textY.setText(String.valueOf("Y:" + String.format("%.1f", e.values[1]) + "; yPWM:" + yAxis));
            mLeft.setText(String.valueOf("MotorL:" + directionL + "." + motorLeft));
            mRight.setText(String.valueOf("MotorR:" + directionR + "." + motorRight));
            textCmdSend.setText(String.valueOf("Send:" + cmdSend));
        } else {
            textX.setText("");
            textY.setText("");
            mLeft.setText("");
            mRight.setText("");
            textCmdSend.setText("");
        }
    }

    private void loadPref() {
        SharedPreferences mySharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        xMax = Integer.parseInt(mySharedPreferences.getString("pref_xMax", String.valueOf(xMax)));
        xR = Integer.parseInt(mySharedPreferences.getString("pref_xR", String.valueOf(xR)));
        yMax = Integer.parseInt(mySharedPreferences.getString("pref_yMax", String.valueOf(yMax)));
        yThreshold = Integer.parseInt(mySharedPreferences.getString("pref_yThreshold", String.valueOf(yThreshold)));
        pwmMax = Integer.parseInt(mySharedPreferences.getString("pref_pwmMax", String.valueOf(pwmMax)));
        show_Debug = mySharedPreferences.getBoolean("pref_Debug", false);
        commandLeft = mySharedPreferences.getString("pref_commandLeft", commandLeft);
        commandRight = mySharedPreferences.getString("pref_commandRight", commandRight);
    }

    @Override
    protected void onResume() {
        super.onResume();
        BT_is_connect = bl.BT_Connect(false);

        mSensorManager.registerListener(this, mAccel, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        bl.BT_onPause();

        mSensorManager.unregisterListener(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        loadPref();
    }

    public void onAccuracyChanged(Sensor arg0, int arg1) {
        // TODO Auto-generated method stub
    }
}
