package com.ec535_app;

import java.io.IOException;
import java.util.UUID;
import java.io.InputStream;
import java.io.OutputStream;

import android.bluetooth.BluetoothSocket;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

import static android.bluetooth.BluetoothAdapter.getDefaultAdapter;

public class BTconnect {

    private static BluetoothAdapter btAdapter = null;
    private BluetoothSocket btSocket = null;
    private BluetoothDevice  btDevice = null;
    private OutputStream outStream = null;
    private ConnectedThread mConnectedThread;
    private String GTaddress;

    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private final Handler mHandler;
    public final static int BL_NOT_AVAILABLE = 1;
    public final static int BL_INCORRECT_ADDRESS = 2;
    public final static int BL_REQUEST_ENABLE = 3;
    public final static int BL_SOCKET_FAILED = 4;
    public final static int RECEIVE_MESSAGE = 5;
    public final static int RFCOMM_FAILED = 6;

    BTconnect(BluetoothDevice device, Handler handler, String address){
        GTaddress = address;
        btDevice = device;
        btAdapter = getDefaultAdapter();
        mHandler = handler;
        if (btAdapter == null) {
            mHandler.sendEmptyMessage(BL_NOT_AVAILABLE);
            return;
        }
    }

    public void checkBTState() {
        if(btAdapter == null) {
            mHandler.sendEmptyMessage(BL_NOT_AVAILABLE);
        } else {
            if (!btAdapter.isEnabled()) {
                mHandler.sendEmptyMessage(BL_REQUEST_ENABLE);
            }
        }
    }

    private BluetoothSocket createBluetoothSocket() throws IOException{
        BluetoothSocket tmp = null;
        try{
            tmp = btDevice.createRfcommSocketToServiceRecord(MY_UUID);
        }
        catch (IOException e){
            mHandler.sendEmptyMessage(RFCOMM_FAILED);
        }

        btSocket = tmp;
        return btSocket;
    }

    public boolean BT_Connect(boolean listen_InStream){
        boolean connected = false;

        if(!BluetoothAdapter.checkBluetoothAddress(GTaddress)){
            mHandler.sendEmptyMessage(BL_INCORRECT_ADDRESS);
            return false;
        }
        else{
            try {
                btSocket = createBluetoothSocket();
            }
            catch (IOException e){
                mHandler.sendEmptyMessage(BL_SOCKET_FAILED);
                return false;
            }
        }

        btAdapter.cancelDiscovery();

        try{
            btSocket.connect();
        }
        catch (IOException e){
            try{
                btSocket.close();
            }
            catch (IOException e2){
                mHandler.sendEmptyMessage(BL_SOCKET_FAILED);
                return false;
            }
        }

        try{
            outStream = btSocket.getOutputStream();
            connected = true;
        }
        catch (IOException e){
            mHandler.sendEmptyMessage(BL_SOCKET_FAILED);
            return false;
        }
        if(listen_InStream){
            mConnectedThread = new ConnectedThread();
            mConnectedThread.start();
        }


    return connected;
    }


    public void BT_onPause(){
        if(outStream != null){
            try{
                outStream.flush();
            }
            catch(IOException e){
                mHandler.sendEmptyMessage(BL_SOCKET_FAILED);
                return;
            }
        }

        if(btSocket != null){
            try{
                btSocket.close();
            }
            catch(IOException e2){
                mHandler.sendEmptyMessage(BL_SOCKET_FAILED);
                return;
            }
        }
    }

    public void sendData(String message){
        byte[] msgBuffer = message.getBytes();

        if (outStream != null){
            try{
                outStream.write(msgBuffer);
            }
            catch (IOException e){
                mHandler.sendEmptyMessage(BL_SOCKET_FAILED);
                return;
            }
        }
    }

    private class ConnectedThread extends Thread{
        private final InputStream mmInStream;

        public ConnectedThread(){
            InputStream tmpIn = null;

            try{
                tmpIn = btSocket.getInputStream();
            }
            catch(IOException e){
                ;
            }

            mmInStream = tmpIn;
        }

        public void run(){
            byte[] buffer = new byte[1024];
            int bytes;

            while(true){
                try{
                    bytes = mmInStream.read(buffer);
                    mHandler.obtainMessage(RECEIVE_MESSAGE,bytes,-1,buffer).sendToTarget();
                }
                catch (IOException e){
                    break;
                }
            }
        }
    }
}
